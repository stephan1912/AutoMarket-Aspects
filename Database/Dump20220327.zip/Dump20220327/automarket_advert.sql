-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: automarket
-- ------------------------------------------------------
-- Server version	5.7.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `advert`
--

DROP TABLE IF EXISTS `advert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `advert` (
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `description` varchar(3000) NOT NULL,
  `drivetrain` varchar(255) DEFAULT NULL,
  `engine_cap` int(11) NOT NULL,
  `fuel` varchar(255) DEFAULT NULL,
  `gearbox_type` varchar(255) DEFAULT NULL,
  `horse_power` int(11) NOT NULL,
  `km` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `registered` bit(1) NOT NULL,
  `service_docs` bit(1) NOT NULL,
  `title` varchar(50) NOT NULL,
  `vin` varchar(255) DEFAULT NULL,
  `year` int(11) NOT NULL,
  `body_style_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5hkqc8fc6ms7rwflvrn19dfhx` (`body_style_id`),
  KEY `FK8dvdoawhjaf882jxx4o9ab4a8` (`country_id`),
  KEY `FK9tatnvtavtuucjl0hkd7bnff1` (`model_id`),
  KEY `FKjds5rnsjbg4gr45pmn8bgd7dj` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advert`
--

LOCK TABLES `advert` WRITE;
/*!40000 ALTER TABLE `advert` DISABLE KEYS */;
INSERT INTO `advert` VALUES (67,'2021-05-07 12:53:57','Audi A4 Avant 2013 Facelift, Multitronic, DPF, Euro 5\n\nMotorizare: 2.0 Diesel 143 CP\nCutie de viteze: Multitronic 8+1 trepte\nNorma de poluare: Euro 5\nCuloare: Lava Gray Pearlescent (Vopsea perlata)\nKilometri: 230.000\nVIN: WAUZZZ8K6DA045044\nMasina are anvelope de vara noi (Hankook DOT 2020) si se vinde impreuna cu un set de roti de iarna pe 16\" (se pot vedea in ultima poza).','FATA',1968,'MOTORINA','AUTOMATA',143,230000,9700,_binary '',_binary '','Audi A4 B8 Avant, Facelift','WAUZZZ8K6DA045044',2013,12,60,6,1),(91,'2021-05-08 20:38:10','Audi A5 Sportback TDI Quattro\n\nGarantie dealer pana la 12 luni sau 15.000 km\nAutoturismul verificat tehnic in cadrul retelei Tiriac Auto\nIstoric disponibil\nProvenienta: Import\nNumar chei disponibile: 2\n\nAvantaje client:\n\" Garantie auto rulate\n\" Control tehnic al calitatii\n\" Posibilitate Trade in/ Buy Back\n\" Posibilitate finantare\n\" Posibilitate livrare catre locatiile Tiriac Auto: Bucuresti, Bacau, Brasov, Pitesti, Constanta\n\" Asistenta rutiera optionala 24/7\n\" Consultanta pe parcursul procesului de achizitie\n\" TVA inclus si deductibil\n\nEchipare autovehicul:\nAsistenta parcare\nAsistenta pornire in rampa\nComenzi vocale\nOglinzi retrovizoare pliabile electric\nPachet S-line\nReglare separata a temperaturii pentru locurile din spate\nSistem Start&Stop\nSistem prindere ISOFIX\nSistem Keyless Go\nSistem monitorizare presiune roti\nVolan multifunctional imbracat in piele\n\nAdresa la care auto se poate viziona:\nBd. Expozitiei, nr. 2, Bucuresti, Sectorul 1\n\nProgram:\nLuni – Vineri 09.00-19.00\nSambata 09.','INTEGRALA',1968,'MOTORINA','AUTOMATA',190,69103,28900,_binary '\0',_binary '','Audi A5 Sportback','WAUZZZF5XHA013779',2017,14,60,7,1),(99,'2021-05-09 22:20:03',' Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia Skoda octavia ','FATA',1598,'BENZINA','MANUALA',116,189000,6900,_binary '',_binary '','Skoda Octavia 2','TMBBA21Z39C002304',2012,12,60,11,1),(107,'2021-05-16 23:17:16','BMW SERIA 3 F30\nEfficientdynamics\nMotor 2.0 diesel N47\n135kw / 184cp\nAn. 2014\n\n*Interior M alcantara\n\n*Exterior M Performance\n\n*Frâne M Performance\n\n*Suspensie M Performance\n\n*Sistem audio HARMAN KARDON\n\n*Naviga?ia NBT ( ruleaz? video in mers )\n\n*VOLAN M3 ÎNC?LZIT\n\nCutie sport automata / PADELE\n4 MODURI DE CONDUS sport + / sport / confort / eco\n\n*Proiectoare LED FL OEM\n*Stopuri LED FL OEM\n* Faruri Bi-xenon adaptive cu control faza lunga','SPATE',1968,'BENZINA','AUTOMATA',190,260000,13000,_binary '',_binary '','BMW SERIA 3 F30, M Performance','WBA3D31030J556957',2014,13,59,8,999999997),(114,'2021-05-17 08:07:42','BMW 520D Touring Facelift\nMotorizare: 2.0 Diesel - 184 CP\nNorma de poluare: EURO 6 fara AdBlue\nCutie de viteze automata: 8+1 trepte\nImport recent Germania\nCarte service exclusiv in reprezentanta BMW\nStare tehnica/estetica foarte buna!\nKM 100% reali, la cerere ofer seria de sasiu pentru verificare\nACCEPT ORICE TEST AUTORIZAT!','SPATE',1968,'MOTORINA','AUTOMATA',184,240000,10200,_binary '\0',_binary '','BMW Seria 5','WBA5D31020GV81807',2014,12,61,9,999999997),(119,'2021-05-17 08:19:35','** Volkswagen Passat B8 Limusine\n** Motorizare 1.6 TDI 120 CP\n** Norma de Poluare Euro 6\n** Cutie Automata DSG2\n** Culoare GRI\n** An Fabricatie 2016\n\nIMPORT RECENT ! NERULATA RO !\n\nKILOMETRAJ ABSOLUT REAL(FULL ISTORIC REPREZENTANTA)\n\nNU ACCEPT RATE/LEASING/FINANTARE/HALE/VARIANTE AUTO\nNU ACCEPT RATE/LEASING/FINANTARE/HALE/VARIANTE AUTO\nNU ACCEPT RATE/LEASING/FINANTARE/HALE/VARIANTE AUTO\nNU ACCEPT RATE/LEASING/FINANTARE/HALE/VARIANTE AUTO\n\nModel Deosebit--HighLine--\n- Jante Originale 17\n- Ceasuri Full Display(Diferite Configurari)\n- Faruri Full Led+Faza Lunga Automata\n- Stopuri Full Led\n- Front Assist\n- Acc(Adaptiv Cruise Control)\n- Scaun Sofer ErgoComfort\n- Interior Piele+Alcantara(Bej)\n- Bord Bicolor\n- Incalzire in scaunele din Fata\n- Incalzire Volan\n- Incalzire Parbriz\n- Perdeluta Electrica Luneta\n- Camera pentru mersul inapoi\n- Parcare Automata\n- Privacy Glass\n- Volan Sport+Padele F1\n- Sistem Navigatie 3D(MARE) Contine Harta si Limba Romana\n- CarPlay(Android Auto/Apple CarPlay)\n- Ke','FATA',1968,'MOTORINA','AUTOMATA',150,170000,10800,_binary '',_binary '','Passat B8, Bluemotion 4x4','WVWZZZ3CZGE079375',2016,12,60,10,999999998);
/*!40000 ALTER TABLE `advert` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-27 22:10:35
