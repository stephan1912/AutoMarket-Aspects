-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: automarket
-- ------------------------------------------------------
-- Server version	5.7.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `feature`
--

DROP TABLE IF EXISTS `feature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feature` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feature`
--

LOCK TABLES `feature` WRITE;
/*!40000 ALTER TABLE `feature` DISABLE KEYS */;
INSERT INTO `feature` VALUES (16,'Airbag-uri fata'),(17,'ABS'),(18,'Airbag-uri laterale fata'),(19,'CD'),(20,'Computer de bord'),(21,'Controlul stabilitatii (ESP)'),(22,'Servodirectie'),(23,'Inchidere centralizata'),(24,'Radio'),(25,'Airbag genunchi sofer'),(26,'Airbag-uri cortina'),(27,'Airbag-uri laterale spate'),(28,'Aer conditionat doua zone'),(29,'Alarma'),(30,'Bluetooth'),(31,'Camera parcare spate'),(32,'Faruri Xenon'),(33,'Controlul tractiunii (ASR)'),(34,'Comenzi volan'),(35,'Faruri automate'),(36,'Geamuri cu tenta'),(37,'Geamuri laterale spate fumurii'),(38,'Imobilizator electronic'),(39,'Head-up display'),(40,'Geamuri spate electrice'),(42,'Interior din piele'),(43,'Intrare auxiliara'),(44,'Lumini de zi (LED)'),(45,'Limitator de viteza'),(46,'Jante din aliaj usor'),(47,'Navigatie GPS'),(48,'Oglinda retrovizoare interioara electrocromatica'),(49,'Oglinzi retrovizoare ajustabile electric'),(50,'Parbriz incalzit'),(51,'Oglinzi retrovizoare incalzite'),(52,'Pilot automat'),(53,'Proiectoare ceata'),(54,'Senzori parcare spate'),(55,'Scaune fata incalzite'),(56,'Senzori parcare fata-spate'),(57,'Stergatoare parbriz automate'),(58,'Scaune spate incalzite');
/*!40000 ALTER TABLE `feature` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-27 22:10:35
