-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: automarket
-- ------------------------------------------------------
-- Server version	5.7.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `advert_features`
--

DROP TABLE IF EXISTS `advert_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `advert_features` (
  `advert_id` int(11) NOT NULL,
  `feature_id` int(11) NOT NULL,
  KEY `FK9syg4onaa4l5ms94chv3efy4s` (`feature_id`),
  KEY `FKi0w3bxv0f8v8j4ooicsrhjchp` (`advert_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advert_features`
--

LOCK TABLES `advert_features` WRITE;
/*!40000 ALTER TABLE `advert_features` DISABLE KEYS */;
INSERT INTO `advert_features` VALUES (67,57),(67,54),(67,35),(67,28),(67,23),(67,22),(67,21),(67,19),(67,17),(67,24),(67,26),(67,53),(67,56),(67,55),(67,30),(67,20),(67,18),(67,46),(67,52),(67,51),(67,50),(67,45),(67,40),(67,49),(67,48),(67,47),(67,44),(67,43),(67,39),(67,38),(67,37),(67,32),(67,27),(67,29),(67,31),(67,33),(67,34),(67,36),(99,25),(99,19),(91,19),(91,31),(91,35),(91,17),(91,40),(91,39),(91,36),(91,34),(91,44),(91,45),(91,46),(91,43),(91,48),(91,50),(91,49),(91,47),(91,52),(91,54),(91,51),(91,56),(91,53),(91,32),(91,33),(91,30),(91,27),(91,25),(91,22),(91,26),(91,42),(91,28),(91,55),(91,24),(91,58),(99,24),(107,21),(107,37),(107,35),(107,31),(107,25),(107,36),(107,40),(107,39),(107,27),(107,38),(107,28),(107,44),(107,43),(107,46),(114,36),(114,35),(114,37),(114,34),(114,38),(119,25),(119,34),(119,32),(119,52),(119,21);
/*!40000 ALTER TABLE `advert_features` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-27 22:10:36
